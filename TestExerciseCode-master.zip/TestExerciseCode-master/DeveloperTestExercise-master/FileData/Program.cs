﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            bool fileExist = false, validcmd = false;
            string fileName = "";
            FileInfo fl = null;
            Console.WriteLine("Please enter the file Path");
            while (fileExist == false)
            {
                var filepath = Console.ReadLine();
                fl = new FileInfo(@filepath);
                fileExist = fl.Exists;
                if (fileExist == true)
                {
                    fileName = fl.FullName;
                    break;
                }
                else
                    Console.WriteLine("Please enter the Valid Path");

            }

            Console.WriteLine("Please Press -v to get File Version / Press -s to get File size");

            while (validcmd == false)
            {
                var inputcmd = Console.ReadLine();
                Print cmdprint = PrintCommand;
                if (BL_Validation.ValidateCMD(inputcmd, fileName, cmdprint) == true)
                {
                    validcmd = true;
                    break;
                }
                else
                    Console.WriteLine("Please enter the Valid command");

            }
            Console.WriteLine("Press any key to exit");
            Console.Read();

        }
        //private static bool ValidateCMD(string cmd, string filename)
        //{
        //    FileDetails objFile = new FileDetails();
        //    string[] ValidVersionCMD = { "-v", "–v", "--v", "/v", "--version" };
        //    string[] ValidSizeCMD = { "–s", "--s", "/s", "--size" };
        //    if (ValidVersionCMD.Where(vr => vr.ToUpper() == cmd.ToUpper().Trim()).Count() > 0)
        //    {

        //        Console.WriteLine("Version:-" + objFile.Version(filename));
        //        return true;

        //    }
        //    if (ValidSizeCMD.Where(sz => sz.ToUpper() == cmd.ToUpper().Trim()).Count() > 0)
        //    {

        //        Console.WriteLine("Size:-" + objFile.Size(filename));
        //        return true;
        //    }

        //    return false;

        //}
        public static bool PrintCommand(string cmd)
        {
                Console.WriteLine(cmd);
                return true;          
        }

    }
}
