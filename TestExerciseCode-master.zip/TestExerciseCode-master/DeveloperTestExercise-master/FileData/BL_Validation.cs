﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileData
{
    public delegate bool Print(string cmd);
    public class BL_Validation
    {
        public static bool ValidateCMD(string cmd, string filename, Print cmdPrint)
        {
            FileDetails objFile = new FileDetails();
            string[] ValidVersionCMD = { "-v", "-v", "--v", "/v", "--version" };
            string[] ValidSizeCMD = { "-s", "--s", "/s", "--size" };
            if (ValidVersionCMD.Where(vr => vr.ToUpper() == cmd.ToUpper().Trim()).Count() > 0)
            {

                cmdPrint("Version:-" + objFile.Version(filename));
                return true;

            }
            if (ValidSizeCMD.Where(sz => sz.ToUpper() == cmd.ToUpper().Trim()).Count() > 0)
            {

                cmdPrint("Size:-" + objFile.Size(filename));
                return true;
            }

            return false;
        }
    }
}
